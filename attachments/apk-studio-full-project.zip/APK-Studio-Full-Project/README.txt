APK Studio — tam layihə arxivi

Bu arxivdə APK Studio-nun mənbə kodu, workspace/build konfiqurasiyası və hazır production sayt build-i var. node_modules daxil edilməyib; mənbəni yenidən build etmək üçün pnpm install işlədin.

Saytı hostinqə yerləşdirmək üçün:
1. artifacts/apk-studio/dist/public/ qovluğunu açın.
2. Həmin qovluğun İÇİNDƏKİ faylları (index.html, assets/, favicon.svg, robots.txt) hostinqin sayt kök qovluğuna yükləyin.

Mənbədən yenidən build etmək üçün layihə qovluğunda:
  pnpm install
  PORT=18130 BASE_PATH=/ pnpm --filter @workspace/apk-studio run build

Yalnız dist/public məzmununu saytın açıq kökünə yükləyin; TypeScript mənbə kodunu ictimai qovluğa yerləşdirməyin.
